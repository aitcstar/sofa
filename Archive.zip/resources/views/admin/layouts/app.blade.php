<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', 'لوحة التحكم') - SOFA Experience</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Droid+Arabic+Sans:wght@400;700&display=swap" rel="stylesheet">

    <!-- Bootstrap RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-dark: #08203e;
            --primary-light: #33415c;
            --secondary: #ad996f;
            --accent: #979dac;
            --light-bg: #f8f9fa;
        }

        body {
            font-family: 'Cairo', 'Droid Arabic Sans', sans-serif;
            background-color: var(--light-bg);
            color: var(--primary-dark);
        }

        .sidebar {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-light) 100%);
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
            transform: translateX(-5px);
        }

        .main-content {
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin: 20px;
            padding: 30px;
        }
        .border-bottom {
        border-bottom: 2px solid var(--secondary) !important;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-light) 100%);
        border: none;
        border-radius: 8px;
        padding: 10px 25px;
        transition: all 0.3s ease;
    }


        .stats-card {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-light) 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
        }

        .stats-card .icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-light) 100%);
            border: none;
            border-radius: 8px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary-dark) 100%);
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: var(--secondary);
            border: none;
            border-radius: 8px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            background-color: #9c855c;
            transform: translateY(-2px);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table thead th {
            background-color: var(--primary-dark);
            color: white;
            border: none;
            font-weight: 600;
        }

        .table-hover tbody tr:hover {
            background-color: rgba(173, 153, 111, 0.1);
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--primary-dark);
        }

        h1, h2, h3, h4, h5, h6 {
            color: var(--primary-dark);
            font-weight: 700;
        }

        h5 {
            color: #ffffff;
            font-weight: 700;
        }
        .text-primary {
            color: var(--primary-dark) !important;
        }

        .text-secondary {
            color: var(--secondary) !important;
        }

        .bg-primary {
            background-color: var(--primary-dark) !important;
        }

        .bg-secondary {
            background-color: var(--secondary) !important;
        }

        .border-primary {
            border-color: var(--primary-dark) !important;
        }

        .border-secondary {
            border-color: var(--secondary) !important;
        }

        .alert-primary {
            background-color: rgba(8, 32, 62, 0.1);
            border-color: var(--primary-dark);
            color: var(--primary-dark);
        }

        /* تخصيص عناصر النموذج */
        .form-control:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 0.25rem rgba(173, 153, 111, 0.25);
        }

        /* تخصيص الـ pagination */
        .page-item.active .page-link {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .page-link {
            color: var(--primary-dark);
        }

        .page-link:hover {
            color: var(--primary-light);
        }


    .btn-primary:hover {
        background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary-dark) 100%);
        transform: translateY(-2px);
    }

    .form-control:focus {
        border-color: var(--secondary);
        box-shadow: 0 0 0 0.25rem rgba(173, 153, 111, 0.25);
    }

    .card-header {
        font-weight: 600;
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
        color: white;
    }

    .btn-outline-danger {
        color: #dc3545;
        border-color: #dc3545;
    }

    .btn-outline-danger:hover {
        background-color: #dc3545;
        border-color: #dc3545;
        color: white;
    }

    .table-dark {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-light) 100%) !important;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(173, 153, 111, 0.1);
    }

    /*.pagination .page-item.active .page-link {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }*/

    .pagination .page-link {
        color: var(--primary-dark);
    }

    .pagination .page-link:hover {
        color: var(--primary-light);
    }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--secondary);
        box-shadow: 0 0 0 0.25rem rgba(173, 153, 111, 0.25);
    }

    .form-label {
        font-weight: 600;
        color: var(--primary-dark);
        margin-bottom: 8px;
    }

    .form-text {
        font-size: 0.85rem;
        color: #6c757d;
    }

    .text-danger {
        color: #dc3545 !important;
    }
    .btn-primary:hover {
        background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary-dark) 100%);
        transform: translateY(-2px);
    }

    .btn-outline-primary {
        color: var(--primary-dark);
        border-color: var(--primary-dark);
    }

    .btn-outline-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
        color: white;
    }

    .btn-outline-danger {
        color: #dc3545;
        border-color: #dc3545;
    }

    .btn-outline-danger:hover {
        background-color: #dc3545;
        border-color: #dc3545;
        color: white;
    }

    .pagination .page-item.active .page-link {
    background-color: #eaecef;
    border-color: #d8dbde;
}
.form-check-input:checked {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
#testimonialsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#faqsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#heroSlidersTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#blogsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#contactsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#packagesTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#stepsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#aboutTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#categoriesTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#exhibitionsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#questionsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}

#unitsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#helpRequestsTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#orderStagesTable_filter {
    text-align: left !important; /* يحرك البحث لليسار */
}
#leadsTable_filter{
    text-align: left !important; /* يحرك البحث لليسار */
}

#itemsTable_filter{
    text-align: left !important; /* يحرك البحث لليسار */
}

#designsTable_filter{
    text-align: left !important; /* يحرك البحث لليسار */
}
    </style>

    @stack('styles')
</head>

<body>
    @php
        $user = auth('admin')->user() ?? auth('employee')->user();
    @endphp
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="{{ asset('assets/images/logos/logo-white.svg') }}" alt="SOFA Experience" class="mb-2" style="max-width: 180px;">
                    </div>


                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"
                               href="{{ route('admin.dashboard') }}">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                الرئيسية
                            </a>
                        </li>

                        @if($user && ($user->hasPermission('content.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.ready-to-furnish.*') ||  request()->routeIs('admin.testimonials.*') || request()->routeIs('admin.about.*') ||  request()->routeIs('admin.contact.*') || request()->routeIs('admin.survey-questions.*')? 'active' : '' }}"
                               href="#contentMenu" data-bs-toggle="collapse" aria-expanded="{{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.ready-to-furnish.*') ||  request()->routeIs('admin.testimonials.*') || request()->routeIs('admin.about.*') ||  request()->routeIs('admin.contact.*') || request()->routeIs('admin.survey-questions.*')? 'true' : 'false' }}"
                               class="dropdown-toggle">
                                <i class="fas fa-cogs me-2"></i>
                                إدارة المحتوى
                            </a>

                            <!-- Sub-menu رئيسي -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*') || request()->routeIs('admin.home-about.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.ready-to-furnish.*') ||  request()->routeIs('admin.testimonials.*') || request()->routeIs('admin.about.*') ||  request()->routeIs('admin.contact.*') || request()->routeIs('admin.survey-questions.*')? 'show' : '' }}"
                                id="contentMenu">

                                <!-- Sub-menu الصفحة الرئيسية -->
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*') || request()->routeIs('admin.home-about.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.ready-to-furnish.*')? 'active' : '' }}"
                                       href="#homeSubmenu" data-bs-toggle="collapse" aria-expanded="{{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*') || request()->routeIs('admin.home-about.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.oready-to-furnish.*') ||  request()->routeIs('admin.testimonials.*') || request()->routeIs('admin.survey-questions.*')? 'true' : 'false' }}"
                                       class="dropdown-toggle">
                                        <i class="fas fa-home me-2"></i>
                                        الصفحة الرئيسية
                                    </a>

                                    <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.hero-sliders.*') || request()->routeIs('admin.steps.*')  || request()->routeIs('admin.home-about.*') || request()->routeIs('admin.process.*') ||  request()->routeIs('admin.why-choose.*') || request()->routeIs('admin.order-timeline.*') || request()->routeIs('admin.ready-to-furnish.*')  ||  request()->routeIs('admin.testimonials.*') || request()->routeIs('admin.survey-questions.*')? 'show' : '' }}"  id="homeSubmenu">
                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.hero-sliders.*') ? 'active' : '' }}"
                                               href="{{ route('admin.hero-sliders.index') }}">
                                                السلايدر
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.steps.*') ? 'active' : '' }}"
                                                href="{{ route('admin.steps.index') }}">
                                                مراحل تجهيز وحدتك
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.home-about.*') ? 'active' : '' }}"
                                                href="{{ route('admin.home-about.edit') }}">
                                                نبذة من نحن
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.survey-questions.*') ? 'active' : '' }}"
                                               href="{{ route('admin.survey-questions.index') }}">
                                               أسئلة اختر الباكج
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.process.*') ? 'active' : '' }}"
                                                href="{{ route('admin.process.edit') }}">
                                                خطوات تأثيث وحدتك
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.why-choose.*') ? 'active' : '' }}"
                                                href="{{ route('admin.why-choose.edit') }}">
                                                لماذا نحن
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.order-timeline.*') ? 'active' : '' }}"
                                                href="{{ route('admin.order-timeline.edit') }}">
                                                تابع تقدم طلبك
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.ready-to-furnish.*') ? 'active' : '' }}"
                                                href="{{ route('admin.ready-to-furnish.edit') }}">
                                                جاهز لتأثيث وحدتك
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link {{ request()->routeIs('admin.testimonials.*') ? 'active' : '' }}"
                                               href="{{ route('admin.testimonials.index') }}">
                                                آراء العملاء
                                            </a>
                                        </li>



                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.about.*') ? 'active' : '' }}"
                                       href="{{ route('admin.about.index') }}">
                                       <i class="fas fa-info-circle me-2"></i>
                                       من نحن
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.contact.*') ? 'active' : '' }}"
                                       href="{{ route('admin.contact.edit') }}">
                                       <i class="fas fa-phone-alt me-2"></i>
                                       اتصل بنا
                                    </a>
                                </li>





                            </ul>
                        </li>
                        @endif

                        {{--@if($user && ($user->hasPermission('surveys.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.survey-questions.*') ? 'active' : '' }}"
                               href="{{ route('admin.survey-questions.index') }}">
                               <i class="fas fa-info-circle me-2"></i>
                               أسئلة اختر الباكج
                            </a>
                        </li>
                        @endif--}}

                        @if($user && ($user->hasPermission('packages.view') || $user->role === 'admin'))
                        <!-- إدارة الباكجات مع Sub-menu-->
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.packages.*') ||  request()->routeIs('admin.units.*') || request()->routeIs('admin.designs.*') || request()->routeIs('admin.items.*') ? 'active' : '' }}"
                            href="#packagesSubmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                                <i class="fas fa-tags me-2"></i>
                                إدارة الباكجات
                            </a>

                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.packages.*') ||   request()->routeIs('admin.units.*') ||  request()->routeIs('admin.designs.*') || request()->routeIs('admin.items.*') ? 'show' : '' }}"
                                id="packagesSubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.packages.index') ? 'active' : '' }}"
                                    href="{{ route('admin.packages.index') }}">
                                        <i class="fas fa-boxes me-2"></i>
                                        الباكجات
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.designs.*') ? 'active' : '' }}"
                                    href="{{ route('admin.designs.index') }}">
                                        <i class="fas fa-palette me-2"></i>
                                         انواع التصاميم
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.units.*') ? 'active' : '' }}"
                                    href="{{ route('admin.units.index') }}">
                                        <i class="fas fa-palette me-2"></i>
                                        الوحدات
                                    </a>
                                </li>


                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.items.*') ? 'active' : '' }}"
                                    href="{{ route('admin.items.index') }}">
                                        <i class="fas fa-box me-2"></i>
                                         القطع
                                    </a>
                                </li>
                            </ul>
                        </li>
                        @endif

                        @if($user && ($user->hasPermission('blogs.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.blogs.*') || request()->routeIs('admin.blog_categories.*') ? 'active' : '' }}"
                            href="#blogsSubmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fas fa-blog me-2"></i>
                                إدارة المدونات
                            </a>

                            <!-- Sub-menu -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.blogs.*') || request()->routeIs('admin.blog_categories.*') ? 'show' : '' }}"
                                id="blogsSubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.blog_categories.*') ? 'active' : '' }}"
                                    href="{{ route('admin.blog_categories.index') }}">
                                        <i class="fas fa-boxes me-2"></i>
                                        أقسام المدونة
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.blogs.*') ? 'active' : '' }}"
                                    href="{{ route('admin.blogs.index') }}">
                                        <i class="fas fa-palette me-2"></i>
                                        المدونة
                                    </a>
                                </li>
                            </ul>
                        </li>
                        @endif

                        @if($user && ($user->hasPermission('exhibitions.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.exhibitions.*') || request()->routeIs('admin.exhibition-categories.*') ? 'active' : '' }}"
                            href="#exhibitionsSubmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                                <i class="fas fa-store-alt me-2"></i> {{-- أيقونة رئيسية للمعارض --}}
                                إدارة المعارض
                            </a>

                            <!-- Sub-menu -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.exhibitions.*') || request()->routeIs('admin.exhibition-categories.*') ? 'show' : '' }}"
                                id="exhibitionsSubmenu">

                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.exhibition-categories.*') ? 'active' : '' }}"
                                    href="{{ route('admin.exhibition-categories.index') }}">
                                        <i class="fas fa-th-list me-2"></i> {{-- أيقونة للأقسام --}}
                                        أقسام المعرض
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.exhibitions.*') ? 'active' : '' }}"
                                    href="{{ route('admin.exhibitions.index') }}">
                                        <i class="fas fa-images me-2"></i> {{-- أيقونة للمعارض نفسها --}}
                                        المعرض
                                    </a>
                                </li>
                            </ul>
                        </li>
                        @endif

                        <!-- Orders Management -->
                        @if($user && ($user->hasPermission('orders.view') || $user->role === 'admin'))
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('admin.orders.*') ? 'active' : '' }}"
                                href="#ordersSubmenu" data-bs-toggle="collapse"
                                aria-expanded="{{ request()->routeIs('admin.orders.*') ? 'true' : 'false' }}"
                                class="dropdown-toggle">
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    إدارة الطلبات
                                </a>

                                <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.orders.*') ? 'show' : '' }}" id="ordersSubmenu">
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.orders.enhanced.index') ? 'active' : '' }}"
                                        href="{{ route('admin.orders.enhanced.index') }}">
                                            جميع الطلبات
                                        </a>
                                    </li>

                                    @if($user && ($user->hasPermission('orders.create') || $user->role === 'admin'))
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.orders.enhanced.create') ? 'active' : '' }}"
                                        href="{{ route('admin.orders.enhanced.create') }}">
                                            إضافة طلب جديد
                                        </a>
                                    </li>
                                    @endif

                                    @if($user && ($user->hasPermission('orderstages.view') || $user->role === 'admin'))
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.order_stages.index') ? 'active' : '' }}"
                                        href="{{ route('admin.order_stages.index') }}">
                                            مراحل الطلب
                                        </a>
                                    </li>
                                    @endif

                                    @if($user && ($user->hasPermission('orders.reports') || $user->role === 'admin'))
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.orders.enhanced.reports*') ? 'active' : '' }}"
                                        href="{{ route('admin.orders.enhanced.reports') }}">
                                            تقارير الطلبات
                                        </a>
                                    </li>
                                    @endif
                                </ul>
                            </li>
                        @endif


                    <!-- Financial Management -->
                    @if($user && ($user->hasPermission('financial.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.financial*') ? 'active' : '' }}"
                            href="#financialSubmenu" data-bs-toggle="collapse" aria-expanded="{{ request()->routeIs('admin.financial*') ? 'true' : 'false' }}" class="dropdown-toggle">
                            <i class="fas fa-dollar-sign me-2"></i>
                            النظام المالي
                            </a>

                            <!-- Sub-menu -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.financial*') ? 'show' : '' }}" id="financialSubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.financial.index') ? 'active' : '' }}"
                                    href="{{ route('admin.financial.index') }}">
                                        لوحة التحكم المالية
                                    </a>
                                </li>

                                @if($user && ($user->hasPermission('financial.invoices.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.financial.invoices*') ? 'active' : '' }}"
                                    href="{{ route('admin.financial.invoices.index') }}">
                                        إدارة الفواتير
                                    </a>
                                </li>
                                @endif
                                @if($user && ($user->hasPermission('financial.payments.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.financial.payments*') ? 'active' : '' }}"
                                    href="{{ route('admin.financial.payments.index') }}">
                                        إدارة المدفوعات
                                    </a>
                                </li>
                                @endif
                            </ul>
                        </li>
                    @endif

                    @if($user && ($user->hasPermission('crm.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.crm*') ? 'active' : '' }}"
                            href="#crmSubmenu" data-bs-toggle="collapse"
                            aria-expanded="{{ request()->routeIs('admin.crm*') ? 'true' : 'false' }}" class="dropdown-toggle">
                                <i class="fas fa-users me-2"></i>
                                إدارة العملاء
                            </a>

                            <!-- Sub-menu -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.crm*') ? 'show' : '' }}" id="crmSubmenu">

                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.crm.index') ? 'active' : '' }}"
                                    href="{{ route('admin.crm.index') }}">
                                        لوحة تحكم
                                    </a>
                                </li>
                                @if($user && ($user->hasPermission('crm.leads.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.crm.leads*') ? 'active' : '' }}"
                                    href="{{ route('admin.crm.leads.index') }}">
                                        إدارة العملاء المحتملين
                                    </a>
                                </li>
                                @endif
                                @if($user && ($user->hasPermission('crm.quotes.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.crm.quotes*') ? 'active' : '' }}"
                                    href="{{ route('admin.crm.quotes.index') }}">
                                        إدارة العروض
                                    </a>
                                </li>
                                @endif

                                @if($user && ($user->hasPermission('crm.funnel') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.crm.funnel*') ? 'active' : '' }}"
                                    href="{{ route('admin.crm.funnel') }}">
                                    المبيعات
                                    </a>
                                </li>
                                @endif
                                @if($user && ($user->hasPermission('crm.activities') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.crm.activities*') ? 'active' : '' }}"
                                    href="{{ route('admin.crm.activities') }}">
                                    سجل الأنشطة
                                    </a>
                                </li>
                                @endif

                            </ul>
                        </li>
                    @endif

                    @if($user && ($user->hasPermission('marketing.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.marketing*') ? 'active' : '' }}"
                            href="#marketingSubmenu" data-bs-toggle="collapse"
                            aria-expanded="{{ request()->routeIs('admin.marketing*') ? 'true' : 'false' }}" class="dropdown-toggle">
                            <i class="fas fa-chart-pie me-2"></i>

                                التسويق والحملات
                            </a>

                            <!-- Sub-menu -->
                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.marketing*') ? 'show' : '' }}" id="marketingSubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.marketing.index') ? 'active' : '' }}"
                                    href="{{ route('admin.marketing.index') }}">
                                        لوحة التسويق
                                    </a>
                                </li>
                                @if($user && ($user->hasPermission('marketing.campaigns.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.marketing.campaigns*') ? 'active' : '' }}"
                                    href="{{ route('admin.marketing.campaigns.index') }}">
                                        إدارة الحملات
                                    </a>
                                </li>
                                @endif
                                @if($user && ($user->hasPermission('marketing.coupons.view') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.marketing.coupons*') ? 'active' : '' }}"
                                    href="{{ route('admin.marketing.coupons.index') }}">
                                        إدارة الكوبونات
                                    </a>
                                </li>
                                 @endif
                                 @if($user && ($user->hasPermission('marketing.analytics') || $user->role === 'admin'))
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.marketing.analytics') ? 'active' : '' }}"
                                    href="{{ route('admin.marketing.analytics') }}">
                                        تحليلات التسويق
                                    </a>
                                </li>
                                @endif
                            </ul>
                        </li>
                    @endif

                    @if($user && ($user->hasPermission('employees.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.employees*') || request()->routeIs('admin.permissions*') ||  request()->routeIs('admin.roles*') ? 'active' : '' }}"
                            href="#employeeSubmenu" data-bs-toggle="collapse"
                            aria-expanded="{{ request()->routeIs('admin.employees*') || request()->routeIs('admin.permissions*') ? 'true' : 'false' }}" class="dropdown-toggle">
                                <i class="fas fa-user-check me-2"></i>
                                إدارة الموظفين
                            </a>

                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.employees*') || request()->routeIs('admin.permissions*') ||  request()->routeIs('admin.roles*')? 'show' : '' }}" id="employeeSubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.employees*') ? 'active' : '' }}"
                                    href="{{ route('admin.employees.index') }}"> الموظفين</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.roles*') ? 'active' : '' }}"
                                    href="{{ route('admin.roles.index') }}">الأدوار والصلاحيات</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.permissions.matrix') ? 'active' : '' }}"
                                    href="{{ route('admin.employees.permissions.matrix') }}">مصفوفة الصلاحيات</a>
                                </li>

                            </ul>
                        </li>
                    @endif

                    @if($user && ($user->hasPermission('security.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.security*') ? 'active' : '' }}"
                            href="#securitySubmenu" data-bs-toggle="collapse"
                            aria-expanded="{{ request()->routeIs('admin.security*') ? 'true' : 'false' }}" class="dropdown-toggle">
                                <i class="fas fa-shield-alt me-2"></i>
                                الأمان والحماية
                            </a>

                            <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.security*') ? 'show' : '' }}" id="securitySubmenu">
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.security.index') ? 'active' : '' }}"
                                    href="{{ route('admin.security.index') }}">لوحة الأمان</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.security.logs') ? 'active' : '' }}"
                                    href="{{ route('admin.security.logs') }}">سجلات الأمان</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.security.failed-logins') ? 'active' : '' }}"
                                    href="{{ route('admin.security.failed-logins') }}">محاولات الدخول الفاشلة</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link {{ request()->routeIs('admin.security.analytics') ? 'active' : '' }}"
                                    href="{{ route('admin.security.analytics') }}">تحليلات الأمان</a>
                                </li>
                            </ul>
                        </li>
                    @endif


                    @if($user && ($user->hasPermission('faqs.view') || $user->role === 'admin'))
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('admin.faqs.*') || request()->routeIs('admin.faq-categories.*') ? 'active' : '' }}"
                        href="#faqsSubmenu" data-bs-toggle="collapse"
                        aria-expanded="{{ request()->routeIs('admin.faqs.*') || request()->routeIs('admin.faq-categories.*') ? 'true' : 'false' }}" class="dropdown-toggle">
                        <i class="fas fa-comments me-2"></i>
                            الأسئلة الشائعة
                        </a>

                        <ul class="collapse list-unstyled ms-3 {{ request()->routeIs('admin.faqs.*') || request()->routeIs('admin.faq-categories.*') ? 'show' : '' }}" id="faqsSubmenu">
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('admin.faq-categories.*') ? 'active' : '' }}"
                                href="{{ route('admin.faq-categories.index') }}"> الاقسام</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('admin.faqs.*') ? 'active' : '' }}"
                                href="{{ route('admin.faqs.index') }}">الأسئلة</a>
                            </li>

                        </ul>
                    </li>
                @endif







                        @if($user && ($user->hasPermission('help.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.help.*') ? 'active' : '' }}"
                            href="{{ route('admin.help.index') }}">
                            <i class="fas fa-headset me-2"></i>
                                    طلب بمساعدة
                            </a>
                        </li>
                        @endif

                        @if($user && ($user->hasPermission('contacts.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.contacts.*') ? 'active' : '' }}"
                               href="{{ route('admin.contacts.index') }}">
                                <i class="fas fa-envelope me-2"></i>
                               رسائل اتصل بنا
                            </a>
                        </li>
                        @endif

                        <hr>
                        @if($user && ($user->hasPermission('settings.view') || $user->role === 'admin'))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}"
                               href="{{ route('admin.settings.edit') }}">
                                <i class="fas fa-cogs me-2"></i>
                                إعدادات الموقع
                            </a>
                        </li>
                        @endif




                        <li class="nav-item">
                            <form method="POST" action="{{ route('admin.logout') }}">
                                @csrf
                                <a class="nav-link" href="#"
                                   onclick="event.preventDefault(); this.closest('form').submit();">
                                    <i class="fas fa-sign-out-alt me-2"></i>
                                    تسجيل الخروج
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="main-content">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @yield('content')
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


    @stack('scripts')
</body>
</html>
