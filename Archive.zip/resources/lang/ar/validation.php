<?php
return [
    'required' => 'حقل :attribute مطلوب.',
    'unique'   => 'حقل :attribute مستخدم مسبقًا.',
    'email'    => 'صيغة البريد الإلكتروني غير صحيحة.',
];
