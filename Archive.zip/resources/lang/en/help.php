<?php

return [
    'name' => 'Full Name',
    'company' => 'Company Name (if any)',
    'email' => 'Email Address',
    'search' => 'Search here',
    'phone_placeholder' => 'e.g. 5xxxxxxx',
    'units' => 'Number of units / Project size',
    'message' => 'Additional notes or special requests',
    'submit' => 'Send Request',
    'helper_text' => 'We will contact you within 48 hours',
];
