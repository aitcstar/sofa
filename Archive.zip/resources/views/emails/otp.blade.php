<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
</head>
<body style="direction: rtl; font-family: Tahoma;">
    <h2>رمز التحقق</h2>
    <p>رمز التحقق الخاص بك هو:</p>
    <h1 style="color:#ad996f">{{ $otp }}</h1>
    <p>الرمز صالح لمدة 5 دقائق.</p>
</body>
</html>
