<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>جاري معالجة طلبك...</title>
    <style>
        body { display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; font-family: 'Cairo', sans-serif; background-color: #f9f9f9; margin: 0; }
        .loader { border: 8px solid #f3f3f3; border-top: 8px solid #3498db; border-radius: 50%; width: 60px; height: 60px; animation: spin 1.5s linear infinite; }
        p { color: #555; font-size: 1.2em; margin-top: 20px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="loader"></div>
    <p>جاري إتمام طلبك، يرجى الانتظار...</p>

    {{-- هذا النموذج سيتم إرساله تلقائياً ولن يكون مرئياً للمستخدم --}}
    <form id="auto-submit-form" action="{{ route('cart.placeOrder') }}" method="POST" style="display: none;">
        @csrf
        {{-- سيتم ملء الحقول هنا تلقائياً باستخدام JavaScript --}}
    </form>

    <script>
        // استرداد بيانات الطلب التي تم حفظها في الجلسة
        const checkoutData = @json(session()->pull('checkout_form_data', []));

        const form = document.getElementById('auto-submit-form');

        // التأكد من وجود بيانات قبل محاولة الإرسال
        if (Object.keys(checkoutData).length > 0) {
            // إضافة البيانات كحقول مخفية إلى النموذج
            for (const key in checkoutData) {
                if (checkoutData.hasOwnProperty(key)) {
                    const hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = key;
                    // التعامل مع البيانات التي قد تكون كائنًا (مثل cart_data)
                    hiddenInput.value = typeof checkoutData[key] === 'object' ? JSON.stringify(checkoutData[key]) : checkoutData[key];
                    form.appendChild(hiddenInput);
                }
            }

            // إرسال النموذج تلقائياً
            document.addEventListener('DOMContentLoaded', function() {
                form.submit();
            });
        } else {
            // إذا لم توجد بيانات، أعد التوجيه للصفحة الرئيسية لمنع بقاء المستخدم عالقاً
            window.location.href = "{{ route('home') }}";
        }
    </script>
</body>
</html>
