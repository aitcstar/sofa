@extends('admin.layouts.app')

@section('title', isset($unit) ? 'تعديل الوحدة' : 'إنشاء وحدة')

@section('content')
<div class="container">
    <!-- Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">{{ isset($unit) ? 'تعديل الوحدة' : 'إنشاء وحدة جديدة' }}</h1>
        <a href="{{ route('admin.units.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-right me-1"></i> رجوع
        </a>
    </div>

    <!-- Card -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">معلومات الوحدة</h5>
        </div>
        <div class="card-body">
            <form action="{{ isset($unit) ? route('admin.units.update', $unit) : route('admin.units.store') }}"
                  method="POST" enctype="multipart/form-data">
                @csrf
                @if(isset($unit)) @method('PUT') @endif



                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>الاسم (AR)</label>
                        <input type="text" name="name_ar" class="form-control" value="{{ $unit->name_ar ?? old('name_ar') }}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>الاسم (EN)</label>
                        <input type="text" name="name_en" class="form-control" value="{{ $unit->name_en ?? old('name_en') }}" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label>النوع</label>
                    <select name="type" class="form-select" required>
                        <option value="bedroom" {{ isset($unit) && $unit->type == 'bedroom' ? 'selected' : '' }}>غرفة نوم</option>
                        <option value="living_room" {{ isset($unit) && $unit->type == 'living_room' ? 'selected' : '' }}>غرفة معيشة</option>
                        <option value="kitchen" {{ isset($unit) && $unit->type == 'kitchen' ? 'selected' : '' }}>مطبخ</option>
                        <option value="bathroom" {{ isset($unit) && $unit->type == 'bathroom' ? 'selected' : '' }}>حمام</option>
                        <option value="external" {{ isset($unit) && $unit->type == 'external' ? 'selected' : '' }}>الملحقات الخارجية والإضافية</option>
                    </select>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label>الباكج</label>
                        <select name="package_id" id="package_select" class="form-select">
                            @foreach($packages as $package)
                                <option value="{{ $package->id }}"
                                    {{ $unit->package_id == $package->id ? 'selected' : '' }}>
                                    {{ $package->name_ar }}
                                </option>
                            @endforeach
                        </select>

                       {{--
                        <select name="package_id" class="form-select">
                            @foreach($packages as $package)
                                <option value="{{ $package->id }}"
                                    {{ $unit->package_id == $package->id ? 'selected' : '' }}>
                                    {{ $package->name_ar }}
                                </option>
                            @endforeach
                        </select>
                    --}}
                    </div>
                </div>

                <div class="mb-3">
                    <label>الوصف (AR)</label>
                    <textarea name="description_ar" class="form-control">{{ $unit->description_ar ?? old('description_ar') }}</textarea>
                </div>

                <div class="mb-3">
                    <label>الوصف (EN)</label>
                    <textarea name="description_en" class="form-control">{{ $unit->description_en ?? old('description_en') }}</textarea>
                </div>

                <!--
                <div class="mb-3">
                    <label>التصميمات المرتبطة والوحدة الحالية</label>
                    <div class="border rounded p-3" style="max-height: 400px; overflow-y: auto;">
                        @foreach($designs as $design)
                        <div class="form-check mb-3">
                            <input
                                type="checkbox"
                                name="design_ids[]"
                                value="{{ $design->id }}"
                                id="design_{{ $design->id }}"
                                class="form-check-input design-checkbox"
                                data-design-id="{{ $design->id }}"
                                {{ isset($selectedDesigns) && in_array($design->id, $selectedDesigns) ? 'checked' : '' }}
                            >
                            <label for="design_{{ $design->id }}" class="form-check-label">
                                {{ $design->name_ar }} ({{ $design->name_en }})
                            </label>

                            <div class="mt-2">
                                <strong>صور {{ $design->name_ar }}</strong>
                                <div class="row mb-2">
                                    @foreach($designImages->where('design_id', $design->id) as $image)
                                        <div class="col-md-3 mb-2 position-relative" style="    width: 170px;">
                                            <img src="{{ asset('storage/'.$image->image_path) }}" class="img-fluid border rounded">
                                            <button type="button" class="btn btn-sm btn-danger delete-image"
                                                    data-unit="{{ $unit->id }}"
                                                    data-image="{{ $image->id }}"
                                                    style="position:absolute; top:5px; right:5px;">
                                                ✕
                                            </button>
                                        </div>
                                    @endforeach
                                </div>
                                <input type="file" name="design_images[{{ $design->id }}][]" class="form-control mt-1" multiple>
                            </div>
                        </div>
                    @endforeach

                    </div>
                </div>
                -->

            <div class="mb-3">
                <label>التصميمات المرتبطة بالباكج</label>
                <div class="border rounded p-3" id="designs_container" style="max-height: 400px; overflow-y: auto;">
                    <!-- سيتم ملؤه ديناميكياً -->
                </div>
            </div>







                @if(isset($unitImages) && $unitImages->count())
                <div class="mb-3">
                    <label>صور الوحدة الحالية</label>
                    <div class="row">
                        @foreach($unitImages as $image)
                            <div class="col-md-3 mb-2 position-relative">
                                <img src="{{ asset('storage/'.$image->image_path) }}" class="img-fluid border rounded">
                                <button class="btn btn-sm btn-danger delete-image"
                                        data-unit="{{ $unit->id }}"
                                        data-image="{{ $image->id }}"
                                        style="position:absolute; top:5px; right:5px;">
                                    ✕
                                </button>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif


                <div class="d-flex gap-2 mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> {{ isset($unit) ? 'تحديث الوحدة' : 'إنشاء الوحدة' }}
                    </button>
                    <a href="{{ route('admin.units.index') }}" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i> إلغاء
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.delete-image').click(function(e){
        e.preventDefault();

        if(!confirm('هل تريد حذف الصورة؟')) return;

        var button = $(this);
        var unitId = button.data('unit');
        var imageId = button.data('image');

        $.ajax({
            url: '/admin/units/' + unitId + '/images/' + imageId,
            type: 'DELETE',
            data: {
                _token: '{{ csrf_token() }}'
            },
            success: function(response){
                if(response.success){
                    button.closest('.col-md-3').remove();
                } else {
                    alert('حدث خطأ أثناء الحذف');
                }
            },
            error: function(xhr){
                alert('حدث خطأ أثناء الحذف');
            }
        });
    });
});
</script>


<script>
    $(document).ready(function() {

        function loadDesigns(packageId, selectedDesigns = [], designImages = {}) {
            const container = $('#designs_container');

            if (!packageId) {
                container.html('<div class="text-muted">اختر باكج أولاً</div>');
                return;
            }

            container.html('جاري التحميل...');

            $.getJSON(`/admin/packages/${packageId}/designs-from-units`, function(designs) {

                if (!designs.length) {
                    container.html('<div class="text-danger">لا يوجد تصميمات لهذا الباكج</div>');
                    return;
                }

                let html = '';

                designs.forEach(design => {

                    const isChecked = selectedDesigns.includes(design.id) ? 'checked' : '';
                    let imagesHtml = '';

                    if (designImages[design.id]) {
                        imagesHtml += '<div class="row mb-2">';
                        designImages[design.id].forEach(image => {
                            imagesHtml += `
                            <div class="col-md-3 mb-2 position-relative" style="width: 170px;">
                                <img src="${image.url}" class="img-fluid border rounded">
                                <button type="button" class="btn btn-sm btn-danger delete-image"
                                        data-unit="${image.unitId}"
                                        data-image="${image.id}"
                                        style="position:absolute; top:5px; right:5px;">✕</button>
                            </div>`;
                        });
                        imagesHtml += '</div>';
                    }

                    html += `
                    <div class="form-check mb-3">
                        <input type="checkbox"
                            name="design_ids[]"
                            value="${design.id}"
                            id="design_${design.id}"
                            class="form-check-input design-checkbox"
                            data-design-id="${design.id}"
                            ${isChecked}
                        >
                        <label for="design_${design.id}" class="form-check-label">
                            ${design.name_ar} (${design.name_en})
                        </label>

                        <div class="mt-2 design-images" id="images_for_${design.id}" style="display:${isChecked ? 'block' : 'none'};">
                            <strong>صور ${design.name_ar}</strong>
                            ${imagesHtml}
                            <input type="file" name="design_images[${design.id}][]" class="form-control mt-1" multiple>
                        </div>
                    </div>`;
                });

                container.html(html);
            });
        }

        // عند تغيير الباكج
        $('#package_select').change(function() {
            const packageId = $(this).val();
            loadDesigns(packageId); // عند تغيير الباكج لا نرسل selectedImages
        });

        // عند التحميل الأولي (للتعديل) نعرض التصميمات الحالية والصور
        const initialPackageId = $('#package_select').val();
        const selectedDesigns = @json($selectedDesigns);

        // تجهيز الصور الحالية لكل تصميم
        const designImages = {};
        @foreach($designImages as $image)
            if (!designImages[{{ $image->design_id }}]) designImages[{{ $image->design_id }}] = [];
            designImages[{{ $image->design_id }}].push({
                id: {{ $image->id }},
                url: "{{ asset('storage/'.$image->image_path) }}",
                unitId: {{ $unit->id }}
            });
        @endforeach

        loadDesigns(initialPackageId, selectedDesigns, designImages);

        // عرض div رفع الصور عند تحديد checkbox
        $(document).on('change', '.design-checkbox', function() {
            const designId = $(this).data('design-id');
            const imagesDiv = $('#images_for_' + designId);
            if ($(this).is(':checked')) {
                imagesDiv.show();
                imagesDiv.find('input[type="file"]').attr('required', true);
            } else {
                imagesDiv.hide();
                imagesDiv.find('input[type="file"]').removeAttr('required').val('');
            }
        });

        // حذف الصور الحالية
        $(document).on('click', '.delete-image', function() {
            if (!confirm('هل تريد حذف الصورة؟')) return;
            const button = $(this);
            const unitId = button.data('unit');
            const imageId = button.data('image');

            $.ajax({
                url: '/admin/units/' + unitId + '/images/' + imageId,
                type: 'DELETE',
                data: {_token: '{{ csrf_token() }}'},
                success: function(res){
                    if(res.success){
                        button.closest('.col-md-3').remove();
                    } else alert('حدث خطأ أثناء الحذف');
                },
                error: function(){ alert('حدث خطأ أثناء الحذف'); }
            });
        });

    });
    </script>


@endsection
