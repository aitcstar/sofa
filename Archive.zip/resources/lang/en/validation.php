<?php
return [
    'required' => 'The :attribute field is required.',
    'unique'   => 'The :attribute has already been taken.',
    'email'    => 'The email format is invalid.',
];
