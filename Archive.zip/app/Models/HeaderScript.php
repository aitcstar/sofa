<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HeaderScript extends Model
{
    protected $fillable = ['title', 'script'];
}
